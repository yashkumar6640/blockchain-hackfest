import React from "react";

export default class Exporter extends React.Component {
  render() {
    return <div>Hello</div>;
  }
}
