import React from "react";
import PaymentProcess from "./../payment_process/paymentProcess.js";

export default class GoodsRecieved extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formSubmitted: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit() {
    this.props.updateStep(8)
    this.setState({
      formSubmitted: true
    });
  }
  render() {
    switch (this.state.formSubmitted) {
      case false:
        return (
          <div>
            <div>inside Goods Recieved</div>
            <div
              className="btn btn-primary btn-block"
              type="submit"
              onClick={this.handleSubmit}
            >
              Submit
            </div>
          </div>
        );

      case true:
        return <PaymentProcess updateStep={this.props.updateStep}/>;
    }
  }
}
